from .random import generate_move_random as generate_move
