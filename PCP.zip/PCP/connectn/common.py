import numpy as np
from typing import Optional
from enum import Enum

# by the help of Konstantine Tsafatinos

BoardPiece = np.int8  # The data type (dtype) of the board
NO_PLAYER = BoardPiece(0)  # board[i, j] == NO_PLAYER, the position is empty
PLAYER1 = BoardPiece(1)  # board[i, j] == PLAYER1 where player 1 has a piece
PLAYER2 = BoardPiece(2)  # board[i, j] == PLAYER2 where player 2 has a piece
PlayerAction = np.int8  # The column to be played


class GameState(Enum):
    IS_WIN = 1
    IS_DRAW = -1
    STILL_PLAYING = 0


def initialize_game_state() -> np.ndarray:
    """
    Returns an ndarray, shape (6, 7) and data type (dtype) BoardPiece,
    initialized to 0 (NO_PLAYER).
    """
    return np.full((6, 7), NO_PLAYER)


def pretty_print_board(board: np.ndarray) -> str:
    """
    Should return `board` converted to a human readable string
    representation, to be used when playing or printing diagnostics
    to the console (stdout). The piece in board[0, 0] should appear
    in the lower-left. Here's an example output:
    |==============|
    |              |
    |              |
    |    X X       |
    |    O X X     |
    |  O X O O     |
    |  O O X X     |
    |==============|
    |0 1 2 3 4 5 6 |
    """
    pretty_board = "|==============|\n"
    for row in board:
        pretty_board += "|"
        for state in row:
            if state == NO_PLAYER:
                pretty_board += "  "
            elif state == PLAYER1:
                pretty_board += "X "
            elif state == PLAYER2:
                pretty_board += "O "
        pretty_board += "|\n"
    pretty_board += "|==============|\n"
    pretty_board += "|0 1 2 3 4 5 6 |"
    return pretty_board


def string_to_board(pp_board: str) -> np.ndarray:
    """
    Takes the output of pretty_print_board and turns it back into an
    ndarray. This is quite useful for debugging, when the agent crashed
    and you have the last board state as a string.
    """
    lines = pp_board.split("\n")
    game_state = np.zeros((6, 7))
    for ind, row in enumerate(lines[1:7]):
        build_row = np.zeros(7)
        for ind2, char in enumerate(row[:-1]):
            if char == '' and ind2 % 2 == 1:
                build_row[int((ind2 - 1) / 2)] = NO_PLAYER
            elif char == 'X':
                build_row[int((ind2 - 1) / 2)] = PLAYER1
            elif char == 'O':
                build_row[int((ind2 - 1) / 2)] = PLAYER2
        game_state[ind] = build_row
    return game_state


def apply_player_action(
        board: np.ndarray,
        action: PlayerAction,
        player: BoardPiece,
        copy: bool = False
) -> np.ndarray:
    """
    Sets board[i, action] = player, where i is the lowest open row.
    The modified board is returned. If copy is True, makes a copy of
    the board before modifying it.
    """
    board_ret = board.copy() if copy else board
    next_row = np.count_nonzero(board_ret, axis=0)[action] - 1
    board_ret[next_row][action] = player
    return board_ret


def connected_four(
        board: np.ndarray,
        player: BoardPiece,
        last_action: Optional[PlayerAction] = None
) -> bool:
    """
    Returns True if there are four adjacent pieces equal to `player`
    arranged in either a horizontal, vertical, or diagonal line.
    Returns False otherwise. If desired, the last action taken
    (i.e. last column played) can be provided for potential
    speed optimisation.
    """
    bools = board == player

    def shift(arr, num, axis, fill_value=0):
        arr_copy = np.roll(arr.copy(), num, axis=axis)
        if axis == 1:
            if num < 0:
                arr_copy[:, num:] = fill_value
            elif num > 0:
                arr_copy[:, :num] = fill_value
        if axis == 0:
            if num < 0:
                arr_copy[num:, :] = fill_value
            elif num > 0:
                arr_copy[:num, :] = fill_value
        return arr_copy

    # check vertical
    v_shift1 = bools & shift(bools, 1, axis=0)
    v_shift2 = v_shift1 & shift(v_shift1, 2, axis=0)
    if v_shift2.any():
        return True

    # check horizontal
    h_shift1 = bools & shift(bools, 1, axis=1)
    h_shift2 = h_shift1 & shift(h_shift1, 2, axis=1)
    if h_shift2.any():
        return True

    # check / diagonal
    pos1 = bools & shift(shift(bools, 1, axis=0), 1, axis=1)
    posmask = pos1 & shift(shift(pos1, 2, axis=0), 2, axis=1)
    if posmask.any():
        return True

    # check \ diagonal
    neg1 = bools & shift(shift(bools, -1, axis=0), 1, axis=1)
    negmask = neg1 & shift(shift(neg1, -2, axis=0), 2, axis=1)
    if negmask.any():
        return True

    return False


def check_end_state(
        board: np.ndarray,
        player: BoardPiece,
        last_action: Optional[PlayerAction] = None
) -> GameState:
    """
    Returns the current game state for the current `player`, i.e. has
    their last action won (GameState.IS_WIN) or drawn
    (GameState.IS_DRAW) the game, or is play still on-going
    (GameState.STILL_PLAYING)?
    """
    if connected_four(board, player):
        return GameState.IS_WIN
    elif np.count_nonzero(board) == 42:
        return GameState.IS_DRAW
    else:
        return GameState.STILL_PLAYING

